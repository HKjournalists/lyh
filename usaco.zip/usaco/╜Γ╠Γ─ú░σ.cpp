/*
ID: sdjllyh1
PROG: 
LANG: C++
complete date: 
complexity: 
author: LiuYongHui From GuiZhou University Of China
more article: www.cnblogs.com/sdjl
*/

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


void Run()
{

}

void Init()
{
	ifstream fin (".in");

	fin.close();
}

void Output()
{
	ofstream fout (".out");

	fout.close();
}

int main() 
{
	Init();
	Run();
	Output();
	return 0;
}