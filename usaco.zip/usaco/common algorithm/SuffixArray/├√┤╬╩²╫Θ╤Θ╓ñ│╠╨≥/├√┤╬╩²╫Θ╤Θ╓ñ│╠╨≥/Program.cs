﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 名次数组验证程序
{
    class Program
    {
        static void Main(string[] args)
        {
            //修改下面的字符串然后运行程序
            string str = "madamimadam#madamimadam";
            int length = str.Length;

            string[] suffix=new string[length];
            for (int i = 0; i < length; i++)
            {
                suffix[i] = str.Substring(i);
            }
            Array.Sort(suffix);

            int[] rank = new int[length];
            for (int i = 0; i < length; i++)
            {
                rank[length - suffix[i].Length] = i;
            }

            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(rank[i].ToString() + "      " + suffix[rank[i]]);
            }
            Console.ReadKey();
        }
    }
}
