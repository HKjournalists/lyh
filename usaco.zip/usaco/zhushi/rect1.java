/*
ID: sdjllyh1
PROG: rect1
LANG: JAVA
complete date: 2009/1/8
author: LiuYongHui From GuiZhou University Of China
more articles: www.cnblogs.com/sdjls
*/

import java.io.*;
import java.util.*;

public class rect1
{
	public static int n;
	public static int[] l, r, t, b, c;
	public static int[] color = new int[2501];

	public static void main(String[] args) throws IOException
	{
		init();
		run();
		output();
		System.exit(0);
	}

	private static void run()
	{
		
		RectangleList rects = new RectangleList(new Rectangle(t[0], b[0], l[0], r[0], 1));
		
		for (int i = n; i > 0; i--)
		{
			
			Rectangle laying = new Rectangle(t[i], b[i], l[i], r[i], c[i]);
			
			List overlaps = rects.overlapRectangles(laying);
			Iterator it = overlaps.iterator();
			
			while (it.hasNext())
			{
				
				Rectangle overlap = (Rectangle)it.next();
				
				color[laying.color] += laying.overlapArea(overlap);
				
				Rectangle[] deRects = laying.decompose(overlap);
				if (deRects != null)
				{
					int length = deRects.length;
					
					for (int j = 0; j < length; j++)
					{
						rects.insertRect(deRects[j]);
					}
				}
				
				rects.deleteRect(overlap);
			}
		}
		
		color[1] = r[0] * t[0];
		for (int i = 2; i <= 2500; i++)
		{
			color[1] -= color[i];
		}

	}

	private static void init() throws IOException
	{
		BufferedReader f = new BufferedReader(new FileReader("rect1.in"));
		char[] buff = new char[40000];
		f.read(buff);
		StringTokenizer st = new StringTokenizer(String.valueOf(buff));

		int right = Integer.parseInt(st.nextToken());
		int top = Integer.parseInt(st.nextToken());
		n = Integer.parseInt(st.nextToken());
		l = new int[n+1];
		r = new int[n+1];
		t = new int[n+1];
		b = new int[n+1];
		c = new int[n+1];

		r[0] = right;
		t[0] = top;

		for (int i = 1; i <= n; i++)
		{
			l[i] = Integer.parseInt(st.nextToken());
			b[i] = Integer.parseInt(st.nextToken());
			r[i] = Integer.parseInt(st.nextToken());
			t[i] = Integer.parseInt(st.nextToken());
			c[i] = Integer.parseInt(st.nextToken());
		}
		f.close();
	}

	private static void output() throws IOException
	{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("rect1.out")));
		for (int i = 1; i <= 2500; i++)
		{
			if (color[i] > 0)
			{
				out.print(i);
				out.print(' ');
				out.println(color[i]);
			}
		}
		out.close();
	}
}

class Rectangle
{
	private int top, bottom, left, right;
	public int color;
	
	public Rectangle(int top, int bottom, int left, int right, int color)
	{
		this.top = top;
		this.bottom = bottom;
		this.left = left;
		this.right = right;
		this.color = color;
	}
	
	public Rectangle[] decompose(Rectangle rect)
	{
		Rectangle[] retList = null;
		int color = rect.color;
		int length;
		
		if ((rect.right <= this.right) && (rect.right >= this.left))
		{
			
			if ((rect.left <= this.right) && (rect.left >= this.left))
			{
				
				
				if ((rect.top <= this.top) && (rect.top >= this.bottom))
				{
					
					if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
					{
						
					}
					else
					{
						
						length = 1;
						Rectangle[] dr = new Rectangle[length];
						retList = dr;
						int[] l = new int[length];
						int[] r = new int[length];
						int[] t = new int[length];
						int[] b = new int[length];

						l[0] = rect.left; r[0] = rect.right; t[0] = this.bottom; b[0] = rect.bottom;

						for (int i = 0; i < length; i++)
							dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
					}
				}
				else if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
				{
					
					length = 1;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = rect.right; t[0] = rect.top; b[0] = this.top;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
				else if ((rect.top >= this.top) && (rect.bottom <= this.bottom))
				{
					
					length = 2;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = rect.right; t[0] = rect.top; b[0] = this.top;
					l[1] = rect.left; r[1] = rect.right; t[1] = this.bottom; b[1] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
			}
			else
			{
				
				
				if ((rect.top <= this.top) && (rect.top >= this.bottom))
				{
					
					if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
					{
						
						length = 1;
						Rectangle[] dr = new Rectangle[length];
						retList = dr;
						int[] l = new int[length];
						int[] r = new int[length];
						int[] t = new int[length];
						int[] b = new int[length];

						l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;

						for (int i = 0; i < length; i++)
							dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
					}
					else
					{
						
						length = 2;
						Rectangle[] dr = new Rectangle[length];
						retList = dr;
						int[] l = new int[length];
						int[] r = new int[length];
						int[] t = new int[length];
						int[] b = new int[length];

						l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
						l[1] = this.left; r[1] = rect.right; t[1] = this.bottom; b[1] = rect.bottom;

						for (int i = 0; i < length; i++)
							dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
					}
				}
				else if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
				{
					
					length = 2;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.left; r[1] = rect.right; t[1] = rect.top; b[1] = this.top;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
				else
				{
					
					length = 3;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.left; r[1] = rect.right; t[1] = rect.top; b[1] = this.top;
					l[2] = this.left; r[2] = rect.right; t[2] = this.bottom; b[2] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
			}
		}
		else if ((rect.left <= this.right) && (rect.left >= this.left))
		{
			
			
			if ((rect.top <= this.top) && (rect.top >= this.bottom))
			{
				
				
				if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
				{
					
					length = 1;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = this.right; r[0] = rect.right; t[0] = rect.top; b[0] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
				else
				{
					
					length = 2;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.right; t[0] = this.bottom; b[0] = rect.bottom;
					l[1] = this.right; r[1] = rect.right; t[1] = rect.top; b[1] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
			}
			else if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
			{
				
				length = 2;
				Rectangle[] dr = new Rectangle[length];
				retList = dr;
				int[] l = new int[length];
				int[] r = new int[length];
				int[] t = new int[length];
				int[] b = new int[length];

				l[0] = rect.left; r[0] = this.right; t[0] = rect.top; b[0] = this.top;
				l[1] = this.right; r[1] = rect.right; t[1] = rect.top; b[1] = rect.bottom;

				for (int i = 0; i < length; i++)
					dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
			}
			else
			{
				
				length = 3;
				Rectangle[] dr = new Rectangle[length];
				retList = dr;
				int[] l = new int[length];
				int[] r = new int[length];
				int[] t = new int[length];
				int[] b = new int[length];

				l[0] = rect.left; r[0] = this.right; t[0] = rect.top; b[0] = this.top;
				l[1] = rect.left; r[1] = this.right; t[1] = this.bottom; b[1] = rect.bottom;
				l[2] = this.right; r[2] = rect.right; t[2] = rect.top; b[2] = rect.bottom;

				for (int i = 0; i < length; i++)
					dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
			}
		}
		else
		{
			
			if ((rect.top <= this.top) && (rect.top >= this.bottom))
			{
				
				if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
				{
					
					length = 2;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.right; r[1] = rect.right; t[1] = rect.top; b[1] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
				else
				{
					
					length = 3;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.left; r[1] = this.right; t[1] = this.bottom; b[1] = rect.bottom;
					l[2] = this.right; r[2] = rect.right; t[2] = rect.top; b[2] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
			}
			else
			{
				
				if ((rect.bottom <= this.top) && (rect.bottom >= this.bottom))
				{
					
					length = 3;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.left; r[1] = this.right; t[1] = rect.top; b[1] = this.top;
					l[2] = this.right; r[2] = rect.right; t[2] = rect.top; b[2] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
				else
				{
					
					length = 4;
					Rectangle[] dr = new Rectangle[length];
					retList = dr;
					int[] l = new int[length];
					int[] r = new int[length];
					int[] t = new int[length];
					int[] b = new int[length];

					l[0] = rect.left; r[0] = this.left; t[0] = rect.top; b[0] = rect.bottom;
					l[1] = this.left; r[1] = this.right; t[1] = rect.top; b[1] = this.top;
					l[2] = this.right; r[2] = rect.right; t[2] = rect.top; b[2] = rect.bottom;
					l[3] = this.left; r[3] = this.right; t[3] = this.bottom; b[3] = rect.bottom;

					for (int i = 0; i < length; i++)
						dr[i] = new Rectangle(t[i], b[i], l[i], r[i], color);
				}
			}
		}
		return retList;
	}
	
	public boolean isOverlap(Rectangle rect)
	{
		int l = Math.max(this.left, rect.left);
		int r = Math.min(this.right, rect.right);
		if (l >= r)
			return false;

		int b = Math.max(this.bottom, rect.bottom);
		int t = Math.min(this.top, rect.top);
		if (b >= t)
			return false;

		return true;
	}
	
	public int overlapArea(Rectangle rect)
	{
		int l = Math.max(this.left, rect.left);
		int r = Math.min(this.right, rect.right);
		if (l >= r)
			return 0;

		int b = Math.max(this.bottom, rect.bottom);
		int t = Math.min(this.top, rect.top);
		if (b >= t)
			return 0;

		int wide = r - l;
		int hight = t - b;

		return wide * hight;
	}
};


class RectangleList
{
	private List listRect = new ArrayList();

	public RectangleList(Rectangle rect)
	{
		listRect.add(rect);
	}
	
	public void insertRect(Rectangle rect)
	{
		listRect.add(rect);
	}
	
	public void deleteRect(Rectangle rect)
	{
		listRect.remove(rect);
	}
	
	public List overlapRectangles(Rectangle rect)
	{
		List retList = new ArrayList();

		Iterator it = listRect.iterator();
		while (it.hasNext())
		{
			Rectangle r = (Rectangle)it.next();
			if (rect.isOverlap(r))
			{
				retList.add(r);
			}
		}

		return retList;
	}
};