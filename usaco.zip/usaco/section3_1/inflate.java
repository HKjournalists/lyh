/*
ID: sdjllyh1
PROG: inflate
LANG: JAVA
complete date: 2008/12/29
complexity: O(n * m)
author: LiuYongHui From GuiZhou University Of China
more articles: www.cnblogs.com/sdjls
*/

import java.io.*;
import java.util.*;

public class inflate
{
	private static int m, n;
	private static int[] points;//ÿ����Ŀ�ĵ÷�
	private static int[] minutes;//ÿ����Ŀ���ѵ�ʱ��
	private static int[] score;//�õ��ķ������±�Ϊ����ʹ�õ�ʱ��
	private static int answer;

	public static void main(String[] args) throws IOException
	{
		init();
		run();
		output();
		System.exit(0);
	}

	private static void run()
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = 1; j <= m; j++)
			{
				if (j >= minutes[i])
				{
					score[j] = Math.max(score[j], score[j - minutes[i]] + points[i]);
				}
			}
		}
		answer = score[m];
	}

	private static void init() throws IOException
	{
		BufferedReader f = new BufferedReader(new FileReader("inflate.in"));
		char[] buff = new char[130000];
		f.read(buff);

		StringTokenizer st = new StringTokenizer(String.valueOf(buff));
		m = Integer.parseInt(st.nextToken());
		n = Integer.parseInt(st.nextToken());

		points = new int[n];
		minutes = new int[n];
		for (int i = 0; i < n; i++)
		{
			points[i] = Integer.parseInt(st.nextToken());
			minutes[i] = Integer.parseInt(st.nextToken());
		}
		f.close();

		score = new int[m+1];
	}

	private static void output() throws IOException
	{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("inflate.out")));
		out.println(answer);
		out.close();
	}
}