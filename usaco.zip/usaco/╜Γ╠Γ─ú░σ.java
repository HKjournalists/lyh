/*
ID: sdjllyh1
PROG: 
LANG: JAVA
complete date: 
complexity: 
author: LiuYongHui From GuiZhou University Of China
more articles: www.cnblogs.com/sdjls
*/

import java.io.*;
import java.util.*;

public class 
{
	public static void main(String[] args) throws IOException
	{
		init();
		run();
		output();
		System.exit(0);
	}

	private static void run()
	{
		
	}
	
	private static void init() throws IOException
	{
		BufferedReader f = new BufferedReader(new FileReader(".in"));
		char[] buff = new char[];
		f.read(buff);
		StringTokenizer st = new StringTokenizer(String.valueOf(buff));

		f.close();
	}

	private static void output() throws IOException
	{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(".out")));
		
		out.close();
	}
}