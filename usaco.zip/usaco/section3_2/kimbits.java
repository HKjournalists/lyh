/*
ID: sdjllyh1
PROG: kimbits
LANG: JAVA
complete date: 2009/1/21
complexity: O(S * L)
author: LiuYongHui From GuiZhou University Of China
more articles: www.cnblogs.com/sdjls
*/

import java.io.*;
import java.util.*;

public class kimbits
{
	private static int S, L;
	private static long I;
	private static StringBuffer answer = new StringBuffer();

	public static void main(String[] args) throws IOException
	{
		init();
		run();
		output();
		System.exit(0);
	}

	private static void run()
	{
		print(S, L, I);
	}
	//�ݹ��������Ϊs�������l��1�ļ����е�i����
	private static void print(int s, int l, long i)
	{
		if (s == 1)
		{
			if (i == 1)
			{
				answer.append('0');
			}
			else
			{
				answer.append('1');
			}
		}
		else
		{
			if (i <= Size(s - 1, l))
			{
				answer.append('0');
				print(s - 1, l, i);
			}
			else
			{
				answer.append('1');
				print(s - 1, l - 1, i - Size(s - 1, l));
			}
		}
	}

	private static long[][] size;//size[s][l]��ʾ����Ϊs�������l��1�ļ��ϴ�С
	private static long unknownSize = -1;//sizeδ֪ʱ��ֵ
	//��ó���Ϊs�������l��1�ļ��ϴ�С
	private static long Size(int s, int l)
	{
		if (size[s][l] != unknownSize)
		{
			return size[s][l];
		}
		else
		{
			size[s][l] = Size(s - 1, l) + Size(s - 1, l - 1);
			return size[s][l];
		}
	}

	private static void init() throws IOException
	{
		BufferedReader f = new BufferedReader(new FileReader("kimbits.in"));
		StringTokenizer st = new StringTokenizer(f.readLine());
		S = Integer.parseInt(st.nextToken());
		L = Integer.parseInt(st.nextToken());
		I = Long.parseLong(st.nextToken());
		f.close();
		size = new long[S+1][L + 1];
		for (int i = 1; i <= S; i++)
		{
			Arrays.fill(size[i], unknownSize);
		}
		Arrays.fill(size[1], 2);
		for (int i = 1; i <= S; i++)
		{
			size[i][0] = 1;
		}
	}

	private static void output() throws IOException
	{
		PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("kimbits.out")));
		out.println(answer);
		out.close();
	}
}