class Factoryoutput < ActiveRecord::Base
  belongs_to :factorymaster
end
