module DbJsHelper
end
