﻿///<reference path="squaresMachineState.js"/>
///<reference path="squareFactory.js"/>

var FallingSquaresMachineState = function(machine) {
    FallingSquaresMachineState.superClass.constructor.call(this, machine);
    this.__life = 0;
    this.__name = "fallingSquaresMachineState";
    this.__storage = 0;
    this.__information = null;
    this.__win = 0;
    this.__last = 0;
}
//类式继承，非static成员写在构造函数中
extend(FallingSquaresMachineState, SquaresMachineState);
FallingSquaresMachineState.name = "falling"; //此名字用于stage.xml文件

FallingSquaresMachineState.prototype.setLife = function(life) {
    this.__life = life;
}

FallingSquaresMachineState.prototype.getLife = function() {
    return this.__life;
}

FallingSquaresMachineState.prototype.__clearDrawedSquares = function() {
    for (var i = 0; i < this.__squares.length; i++) {
        if ((this.__squares[i].getName() == FallingSquare.getName())
        && (this.__squares[i].isExecuted)) {
            this.__readyRemoveSquare(i);
        }
    }
    this.__executRemoveSquares();
}

FallingSquaresMachineState.prototype.__clearFallingSquares = function() {
    for (var i = 0; i < this.__squares.length; i++) {
        if (this.__squares[i].getName() == FallingSquare.getName()) {
            this.__readyRemoveSquare(i);
        }
    }
    this.__executRemoveSquares();
}


FallingSquaresMachineState.prototype.__dead = function() {
    this.__clearFallingSquares();
    this.__life--;

    var floatMessage = SquareFactory.createFloatMessageSquare(languages[language].loseStorageGold+" " + this.__storage + languages[language].Gold + "!", screenHeight - 200, null, 1);
    this.__readyAddSquare(floatMessage);
    this.__machine.addDelay(300);
    this.__last = 0;
    this.__storage = 0;
    this.__updateInformation();
    //如果命还大于0则游戏还没有结束
    if (this.__life > 0) {
        
    }
    else {//否则游戏结束
        //todo
    }

    this.__storage = 0;
    this.__executeAddSquares();
}

FallingSquaresMachineState.prototype.__getSquaresArea = function(squares) {
    var area = 0;
    var length = squares.length;

    for (var i = 0; i < length; i++) {
        area += squares[i].getArea();
    }

    if (length > 1) {
        var areaIncreaseRate = 1 + (length - 1) / 50;
        area = Math.pow(area, areaIncreaseRate);
    }
    return parseInt(area);
}

//获得方块中重叠部分的面积,此函数用到了splitSquares.js
FallingSquaresMachineState.prototype.__getSquaresOverlapArea = function(squares) {
    //获得原总面积
    var totalArea = 0;
    var splitedSquares = new Array();
    for (var i = 0; i < squares.length; i++) {
        totalArea += squares[i].getArea();
        splitedSquares.push(squares[i]);
    }
    //获得分解后的方块及其总面积
    var splitedArea = 0;
    var i = 0;
    while (i < splitedSquares.length) {
        if (splitedSquares[i] != null) {
            var j;
            for (j = i + 1; j < splitedSquares.length; j++) {
                if ((splitedSquares[j] != null) && (splitedSquares[i].isOverlap(splitedSquares[j]))) {
                    var splits = SplitSquare.split(splitedSquares[i], splitedSquares[j]);
                    for (var k = 0; k < splits.length; k++) {
                        splitedSquares.push(splits[k]);
                    }
                    splitedSquares[j] = null;
                }
            }

            splitedArea += splitedSquares[i].getArea();
        }
        i++;
    }
    //返回重叠面积
    return parseInt(totalArea - splitedArea);
}

FallingSquaresMachineState.prototype.__updateInformation = function() {
    this.__information.setLast(this.__last);
    this.__information.setStorage(this.__storage);
    this.__information.setWin(this.__win);
}

FallingSquaresMachineState.prototype.__getDrawedSquares = function() {
    var drawedSquares = new Array();
    for (var i = 0; i < this.__squares.length; i++) {
        if (this.__squares[i].isExecuted) {
            drawedSquares.push(this.__squares[i]);
        }
    }
    return drawedSquares;
}

//=========以下是重新实现(覆盖)基类的函数=========

FallingSquaresMachineState.prototype.nextTime = function() {
    var newSquares = this.__getSquaresFromStage();
    for (var i = 0; i < newSquares.length; i++) {
        if (newSquares[i].getName() == FallingSquare.getName()) {
            this.__readyAddSquare(newSquares[i]);
        }
    }
    var length = this.__squares.length;
    for (var i = 0; i < length; i++) {
        if (this.__squares[i].nextTime()) {
            this.__readyRemoveSquare(i);
        }
    }
    this.__executRemoveSquares();
    this.__executeAddSquares();
    //this.__machine.notifyObservers();
}

FallingSquaresMachineState.prototype.drawSquare = function(mouseSquare) {
    var squares = this.__squares;

    var drawedSquares = new Array();
    for (var i = 0; i < squares.length; i++) {
        if ((!squares[i].isExecuted) && (mouseSquare.isInclude(squares[i]))) {
            drawedSquares.push(squares[i]);
        }
    }

    if (drawedSquares.length > 0) {
        var isDead = false;
        for (var i = 0; i < drawedSquares.length; i++) {
            if (drawedSquares[i].getValue() != FALLINGSQUARE_right) {
                isDead = true;
                break;
            }
        }

        if (!isDead) {
            for (var i = 0; i < drawedSquares.length; i++) {
                drawedSquares[i].execute();
            }
            var thisArea = this.__getSquaresArea(drawedSquares);
            this.__storage += thisArea;
            this.__last = thisArea;
            this.__storage = this.__storage;
            this.__updateInformation();
        }
        else {
            this.__dead();
        }
    }
}

FallingSquaresMachineState.prototype.__initStage = function() {
    this.setLife(parseInt(this.__stage.getAttribute("life")));
    var information = SquareFactory.createInformation(FallingInformation.getName());
    this.__information = information;
    this.__readyAddSquare(information);
    this.__executeAddSquares();
}

FallingSquaresMachineState.prototype.spaceDown = function() {
    if (this.__storage > 0) {
        var overlapArea = this.__getSquaresOverlapArea(this.__getDrawedSquares());

        var win = this.__storage - overlapArea;
        var interest = parseInt(Math.pow(win, 1.02)) - win;

        var message = languages[language].originalGold + this.__storage +  "   "+languages[language].overlapGold +overlapArea+ "   " + languages[language].remainGold + win + "   " + languages[language].interestGold + interest;
        var floatMessage = SquareFactory.createFloatMessageSquare(message);
        this.__readyAddSquare(floatMessage);
        this.__executeAddSquares();

        this.__clearDrawedSquares();

        this.__storage = 0;
        this.__last = 0;
        this.__win += win + interest;
        this.__updateInformation();
    }
}

FallingSquaresMachineState.prototype.__addSquareInit = function(square) { 

}