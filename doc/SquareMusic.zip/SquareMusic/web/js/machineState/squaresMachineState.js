﻿///<reference path="Square.js"/>

var SquaresMachineState = function(machine) {
    this.__machine = machine;
    this.__squares = new Array();
    this.__stage = null;
    this.__squareIndex = 0;
    this.__readyAddSquares = new Array();
    this.__name = "squaresMachineState";
    this.__information = null; 
}

//=================必须被覆盖的方法================
SquaresMachineState.prototype.nextTime = function() {
    alert("出错了：squaresMachineState.js中的nextTime()函数没有被覆盖。调用者："+this.getName());
}

SquaresMachineState.prototype.drawSquare = function(mouseSquare) {
alert("出错了：squaresMachineState.js中的drawSquare()函数没有被覆盖。调用者：" + this.getName());
}

SquaresMachineState.prototype.__initStage = function() {
alert("出错了：squaresMachineState.js中的__initStage()函数没有被覆盖。调用者：" + this.getName());
}

SquaresMachineState.prototype.spaceDown = function() {
    alert("出错了：squaresMachineState.js中的spaceDown()函数没有被覆盖。调用者：" + this.getName());
}

SquaresMachineState.prototype.__addSquareInit = function(square) {
    alert("出错了：squaresMachineState.js中的squaresMachineState()函数没有被覆盖。调用者：" + this.getName());
}
//=================不应该被覆盖的方法==============
SquaresMachineState.prototype.setStage = function(stage) {
    this.__stage = stage;
    this.__squareIndex = 0;
    this.__initStage();
}

SquaresMachineState.prototype.getSquares = function(stage) {
    return this.__squares;
}

SquaresMachineState.prototype.__getSquaresFromStage = function() {
    var retSquares = new Array();
    while ((this.__machine.getDelay() == 0) && (this.__stage != null)
        && (this.__squareIndex < this.__stage.childNodes.length)) {
        while (this.__stage.childNodes[this.__squareIndex].nodeType != 1) {
            this.__squareIndex++;
        }
        var squareXmlDom = this.__stage.childNodes[this.__squareIndex];
        this.__squareIndex++;
        retSquares.push(SquareFactory.createByXmlDom(squareXmlDom));
    }
    return retSquares;
}

SquaresMachineState.prototype.__readyAddSquare = function(square) {
    this.__addSquareInit(square);
    this.__readyAddSquares.push(square);
}

SquaresMachineState.prototype.__readyRemoveSquare = function(index) {
    this.__squares[index].uninit();
    this.__squares[index] = null;
}

SquaresMachineState.prototype.__executeAddSquares = function() {
    var length = this.__readyAddSquares.length;
    for (var i = 0; i < length; i++) {
        this.__squares.push(this.__readyAddSquares[i]);
    }
    this.__readyAddSquares = new Array();
}

SquaresMachineState.prototype.__executRemoveSquares = function() {
    var length = this.__squares.length;
    var i = 0, j = 0;
    while (j < length) {
        while (this.__squares[i] != null) {
            i++;
        }
        j = Math.max(j, i + 1);
        while (j < length && this.__squares[j] == null) {
            j++;
        }
        if (j < length) {
            this.__squares[i] = this.__squares[j];
            this.__squares[j] = null;
        }
    }

    var removeCounter = 0;
    length = this.__squares.length;
    for (; i < length; i++) {
        if (this.__squares[i] == null) {
            removeCounter++;
        }
    }
    this.__squares.length -= removeCounter;
}

SquaresMachineState.prototype.getName = function() {
    return this.__name;
}