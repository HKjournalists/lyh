﻿///<reference path="squaresMachineState.js"/>
///<reference path="squareFactory.js"/>

var SpellingSquaresMachineState = function(machine) {
    SpellingSquaresMachineState.superClass.constructor.call(this, machine);
    this.__name = "SpellingSquaresMachineState";
    this.__speed = 0;
    this.__pauseTime = 0;
    this.__thisPauseTime = 0;
    this.__clicked = true;
}
//类式继承，非static成员写在构造函数中
extend(SpellingSquaresMachineState, SquaresMachineState);
SpellingSquaresMachineState.name = "spelling";//此名字用于stage.xml文件

SpellingSquaresMachineState.prototype.__noFalling = function() {
    var ret = true;
    for (var i = 0; i < this.__squares.length; i++) {
        if (!this.__squares[i].isExecuted) {
            ret = false;
            break;
        }
    }
    return ret;
}

//=========以下是重新实现(覆盖)基类的函数=========
SpellingSquaresMachineState.prototype.nextTime = function() {
    if (this.__thisPauseTime == 0) {
        
        if ((this.__clicked) || (this.__noFalling())) {
            var newSquares = this.__getSquaresFromStage();
            for (var i = 0; i < newSquares.length; i++) {
                this.__readyAddSquare(newSquares[i]);
            }
            this.__clicked = false;
        }
        
        var length = this.__squares.length;
        for (var i = 0; i < length; i++) {
            if (this.__squares[i].nextTime()) {
                this.__readyRemoveSquare(i);
            }
        }
        this.__executRemoveSquares();
        this.__executeAddSquares();
        this.__thisPauseTime = this.__pauseTime;
    }
    else {
        this.__thisPauseTime--;
    }
}

SpellingSquaresMachineState.prototype.drawSquare = function(mouseSquare) {
    if (mouseSquare.getArea() < 10) {
        for (var i = 0; i < this.__squares.length; i++) {
            if (this.__squares[i].getName() == SpellingSquare.getName()) {
                this.__squares[i].execute();
            }
        }
        this.__clicked = true;
    }
    else {
        var squares = this.__squares;
        var drawedSquares = new Array();
        for (var i = 0; i < squares.length; i++) {
            if ((!squares[i].isExecuted) && (mouseSquare.isInclude(squares[i]))) {
                drawedSquares.push(squares[i]);
            }
        }

        for (var i = 0; i < drawedSquares.length; i++) {
            if (drawedSquares[i].getName() != SpellingSquare.getName()) {
                drawedSquares[i].execute();
            }
        }
    }
}

SpellingSquaresMachineState.prototype.__initStage = function() {
    this.__speed = parseInt(this.__stage.getAttribute("speed"));
    this.__pauseTime = parseInt(this.__stage.getAttribute("pause"));
    this.__thisPauseTime = this.__pauseTime;
}

SpellingSquaresMachineState.prototype.spaceDown = function() {

}

SpellingSquaresMachineState.prototype.__addSquareInit = function(square) {
    if (square.getName() == SpellingSquare.getName()) {
        square.setSpeed(this.__speed);
    }
}