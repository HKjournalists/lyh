﻿///<reference path="styleUtil.js"/>
///<reference path="htmlIdConfig.js"/>
///<reference path="classNameConfig.js"/>

var SquareScreen = function(machine) {
    SquareScreen.superClass.constructor.call(this, machine);
    //private
    this.__width = 0;
    this.__height = 0;
    this.__machine = machine;
    this.__squareScreenDiv = document.getElementById(HTMLID_squareScreenDiv);
    this.__controller = null;
}
//继承观察者
extend(SquareScreen, Observer);

SquareScreen.prototype.addSquare = function(squareDom) {
    if (squareDom != null) {
        this.__squareScreenDiv.appendChild(squareDom);
    }
}

SquareScreen.prototype.removeSquare = function(squareDom) {
    if (squareDom != null) {
        this.__squareScreenDiv.removeChild(squareDom);
    }
}

//清除所有的square，除了鼠标画出来的那个
SquareScreen.prototype.__cleanChilds = function() {
    var div = this.__squareScreenDiv;
    if (div != null) {
        //备份鼠标画出来的square
        var drawingMouseDiv = document.getElementById(HTMLID_mouseSquare);
        var parent = div.parentNode;
        parent.removeChild(div);
        var newDiv = document.createElement("div");
        newDiv.id = HTMLID_squareScreenDiv;
        StyleUtil.setClass(newDiv, CLASSNAME_squareScreen);
        //回复鼠标画出来的square
        if (drawingMouseDiv != null) {
            newDiv.appendChild(drawingMouseDiv);
        }
        parent.appendChild(newDiv);
        events_assignSquareScreen(); //重新分配事件函数
        this.__squareScreenDiv = newDiv;
    }
}

SquareScreen.prototype.resize = function(width, height) {
    this.__width = width;
    this.__height = height;
}

//设置控制策略
SquareScreen.prototype.setController = function(controller) {
    this.__controller = controller;
}

SquareScreen.prototype.clearMouseSquare = function() {
    var div = document.getElementById(HTMLID_mouseSquare);
    if (div != null) {
        this.__squareScreenDiv.removeChild(div);
    }
}

SquareScreen.prototype.drawMouseSquare = function(mouseSquare) {
    this.__squareScreenDiv.appendChild(mouseSquare.getSquareDom());
}

//实现Observer的update函数
SquareScreen.prototype.update = function() {
//    var squares = this.__machine.getSquares();
//    this.__cleanChilds();
//    var length = squares.length;
//    for (var i = 0; i < length; i++) {
//        this.__addSquare(squares[i]);
//    }
}