﻿///<reference path="squareScreen.js"/>
///<reference path="squaresMachine.js"/>
///<reference path="squareScreenController.js"/>
///<reference path="Square.js"/>

//全局变量
var squareScreen = null;
var squareScreenController = null;
var squaresMachine = null;
var screenWidth = 0;
var screenHeight = 0;

window.onload = function() {
    squaresMachine = new SquaresMachine();
    squareScreen = new SquareScreen(squaresMachine); //squaresMachine作为主题
    squareScreenController = new SquareScreenController();

    Square.setScreen(squareScreen);
    Square.setMachine(squaresMachine);

    squareScreen.setController(squareScreenController);
    squareScreenController.setSquareScreen(squareScreen);
    squareScreenController.setSquaresMachine(squaresMachine);
    events_assignEvents();

    var url = location.href;
    if (url.indexOf("stage=") > 0) {
        var stageName = url.substring(url.indexOf("stage=") + 6, url.length);
        squaresMachine.loadStage("stages/" + stageName + ".xml");
    }
    else {
        squaresMachine.loadStage("stages/choice.xml");
    }
    window.onresize();
}

window.onresize = function() {
    squareScreen.resize(document.body.clientWidth, document.body.clientHeight);
    screenWidth = document.body.clientWidth;
    screenHeight = document.body.clientHeight;
}