﻿///<reference path="square.js"/>

//生成方块的工厂类

var SquareFactory = {
    __squareId: 0,
    __squaresType: {},
    __squaresConstructor: []
};
SquareFactory.__squaresType[FallingSquare.getName()] = FallingSquare;
SquareFactory.__squaresType[SpellingSquare.getName()] = SpellingSquare;
SquareFactory.__squaresType[DelaySquare.getName()] = DelaySquare;
SquareFactory.__squaresType[PauseSquare.getName()] = PauseSquare;
SquareFactory.__squaresType[StageChoiceSquare.getName()] = StageChoiceSquare;
SquareFactory.__squaresType[Square.getName()] = Square;
SquareFactory.__squaresType[MouseSquare.getName()] = MouseSquare;
SquareFactory.__squaresType[FloatMessageSquare.getName()] = FloatMessageSquare;
SquareFactory.__squaresType[FallingInformation.getName()] = FallingInformation;


SquareFactory.createByXmlDom = function(squareDom) {
    var square = clone(SquareFactory.__squaresType[squareDom.nodeName]);
    var div = document.createElement("div");
    div.innerHTML = "";
    for (var i = 0; i < squareDom.childNodes.length; i++) {
        div.innerHTML += squareDom.childNodes[i].xml;
    }
    square.setSquareDom(div);
    SquareFactory.__squaresConstructor[squareDom.nodeName](square, squareDom);
    SquareFactory.__squareId++;
    square.init();
    return square;
}

SquareFactory.createSquare = function(left, top, width, height) {
    var square = clone(SquareFactory.__squaresType[Square.getName()]);
    var div = document.createElement("div");
    square.setSquareDom(div);

    square.setId("simpleSquare");
    square.setLeft(left);
    square.setTop(top);
    square.setWidth(width);
    square.setHeight(height);
    return square;
}

SquareFactory.createMouseSquare = function(startX, endX, startY, endY) {
    var square = clone(SquareFactory.__squaresType[MouseSquare.getName()]);
    var div = document.createElement("div");
    square.setSquareDom(div);

    square.setId(HTMLID_mouseSquare);
    square.setClass(CLASSNAME_mouseSquare);

    var top = Math.min(startY, endY);
    var bottom = Math.max(startY, endY);
    var left = Math.min(startX, endX);
    var right = Math.max(startX, endX);
    var width = Math.max(0, right - left - cssValue_mouseSquareBorderWidth);
    var height = Math.max(0, bottom - top - cssValue_mouseSquareBorderWidth);
    square.setTop(top);
    square.setLeft(left);
    square.setWidth(width);
    square.setHeight(height);
    return square;
}

SquareFactory.createFloatMessageSquare = function(message, startTop, endTop, speed, className) {
    var square = clone(SquareFactory.__squaresType[FloatMessageSquare.getName()]);
    var div = document.createElement("div");
    square.setSquareDom(div);

    square.setId("floatMessage" + this.__squareId);
    this.__squareId++;
    square.setClass(CLASSNAME_floatMessageSquare);

    if (message != null) {
        square.setMessage(message);
    }
    else {
        alert("出错了！SquareFactory.createFloatMessageSquare()函数使用了null的message构造漂浮消息框。");
    }

    if (startTop != null) {
        square.setStartTop(startTop);
    }
    else {
        square.setStartTop(square.getStartTop());
    }

    if (endTop != null) {
        square.setEndTop(endTop);
    }
    else {
        square.setEndTop(square.getEndTop());
    }

    if (speed != null) {
        square.setSpeed(speed);
    }
    else {
        square.setSpeed(square.getSpeed());
    }

    if (className != null) {
        square.setClass(className);
    }
    else {
        square.setClass(square.getClass());
    }

    square.init();
    return square;
}

//=======以下函数为information系列类的创建函数====================

SquareFactory.createInformation = function(informationName) {
    var square = clone(SquareFactory.__squaresType[informationName]);
    var div = document.createElement("div");
    square.setSquareDom(div);
    
    square.init();
    return square;

}

//=======以下函数为从stage.xml文件中获得Square所需的构造函数=======
SquareFactory.__squaresConstructor[FallingSquare.getName()] = function(square, squareDom) {
square.setSpeed(parseFloat(squareDom.getAttribute("speed")));
square.setValue(parseFloat(squareDom.getAttribute("value")));
    square.setId(squareDom.nodeName + SquareFactory.__squareId);
    square.setTop(squareDom.getAttribute("top"));
    square.setLeft(squareDom.getAttribute("left"));
    square.setWidth(squareDom.getAttribute("width"));
    square.setHeight(squareDom.getAttribute("height"));
    square.setClass(squareDom.getAttribute("class"));
    
}

SquareFactory.__squaresConstructor[SpellingSquare.getName()] = function(square, squareDom) {
    square.setId(squareDom.nodeName + SquareFactory.__squareId);
    square.setTop(squareDom.getAttribute("top"));
    square.setLeft(squareDom.getAttribute("left"));
    square.setWidth(squareDom.getAttribute("width"));
    square.setHeight(squareDom.getAttribute("height"));
    square.setClass(squareDom.getAttribute("class"));
}

SquareFactory.__squaresConstructor[DelaySquare.getName()] = function(square, squareDom) {
    square.setTime(parseInt(squareDom.getAttribute("time")));
}

SquareFactory.__squaresConstructor[PauseSquare.getName()] = function(square, squareDom) {
    square.setWidth(parseInt(squareDom.getAttribute("width")));
    square.setHeight(parseInt(squareDom.getAttribute("height")));
}

SquareFactory.__squaresConstructor[StageChoiceSquare.getName()] = function(square, squareDom) {
    square.setTop(parseInt(squareDom.getAttribute("top")));
    square.setLeft(parseInt(squareDom.getAttribute("left")));
    square.setWidth(parseInt(squareDom.getAttribute("width")));
    square.setHeight(parseInt(squareDom.getAttribute("height")));
    square.setStageName(squareDom.getAttribute("stage"));
}