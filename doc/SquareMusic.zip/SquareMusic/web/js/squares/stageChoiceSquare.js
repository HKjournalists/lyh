﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== StageChoiceSquare类，继承至Square=======

var StageChoiceSquare = clone(Square);
StageChoiceSquare.__name = "stageChoice";
StageChoiceSquare.__finalWidth = 0;
StageChoiceSquare.__finalHeight = 0;
StageChoiceSquare.__interval = null;
StageChoiceSquare.__htmls = null;
StageChoiceSquare.__growupState = "";
StageChoiceSquare.__stageName = null;

StageChoiceSquare.setFinalWidth = function(width) {
    this.__finalWidth = width;
}

StageChoiceSquare.getFinalWidth = function() {
    return this.__finalWidth;
}

StageChoiceSquare.setFinalHeight = function(height) {
    this.__finalHeight = height;
}

StageChoiceSquare.getFinalHeight = function() {
    return this.__finalHeight;
}

StageChoiceSquare.setInterval = function(interval) {
    this.__interval = interval;
}

StageChoiceSquare.getInterval = function() {
    return this.__interval;
}

StageChoiceSquare.setHtmls = function(htmls) {
    this.__htmls = htmls;
}

StageChoiceSquare.getHtmls = function() {
    return this.__htmls;
}

StageChoiceSquare.setStageName = function(stageName) {
    this.__stageName = stageName;
}

StageChoiceSquare.getStageName = function() {
    return this.__stageName;
}


StageChoiceSquare.growup = function(stageChoiceSquare) {
    if ((stageChoiceSquare.getWidth() >= stageChoiceSquare.getFinalWidth())
        && (stageChoiceSquare.getHeight() >= stageChoiceSquare.getFinalHeight())) {
        clearInterval(this.getInterval());
        this.getSquareDom().innerHTML = this.getHtmls();
        this.__growupState = "grown";
    }
    else {
        var width = stageChoiceSquare.getWidth();
        if (width < stageChoiceSquare.getFinalWidth()) {
            width += 5;
            stageChoiceSquare.setWidth(width);
        }

        var height = stageChoiceSquare.getHeight();
        if (height < stageChoiceSquare.getFinalHeight()) {
            height += 5;
            stageChoiceSquare.setHeight(height);
        }
    }
}

//========以下为实现基类的抽象方法=========
StageChoiceSquare.nextTime = function() {

    return false;
}

StageChoiceSquare.init = function() {
    this.setFinalWidth(this.getWidth());
    this.setFinalHeight(this.getHeight());
    this.setWidth(0);
    this.setHeight(0);
    this.setClass(CLASSNAME_stageChoiceSquare);
    this.show();
    this.setHtmls(this.getSquareDom().innerHTML);
    this.getSquareDom().innerHTML = "";
    //设置长大循环
    var me = this;
    var interval = setInterval(function() { me.growup(me) }, 10);
    this.setInterval(interval);
}

StageChoiceSquare.uninit = function() {
    this.hide();
}

StageChoiceSquare.execute = function() {
    var todo = "";
    if (this.__growupState = "grown") {
        var url = location.href;
        if (url.indexOf("?") > 0) {
            url = url.substring(0, url.indexOf("?")) + "?stage=" + this.__stageName;
        }
        else {
            url += "?stage=" + this.__stageName;
        }
        location.href = url;

        this.isExecuted = true;
    }
}