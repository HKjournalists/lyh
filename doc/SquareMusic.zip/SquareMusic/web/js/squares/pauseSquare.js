﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== PauseSquare类，继承至Square=======

var PauseSquare = clone(Square);
PauseSquare.__name = "pause";
PauseSquare.__finalWidth = 0;
PauseSquare.__finalHeight = 0;
PauseSquare.__interval = null;
PauseSquare.__htmls = null;
PauseSquare.__growupState = "";

PauseSquare.setFinalWidth = function(width) {
    this.__finalWidth = width;
}

PauseSquare.getFinalWidth = function() {
    return this.__finalWidth;
}

PauseSquare.setFinalHeight = function(height) {
    this.__finalHeight = height;
}

PauseSquare.getFinalHeight = function() {
    return this.__finalHeight;
}

PauseSquare.setInterval = function(interval) {
    this.__interval = interval;
}

PauseSquare.getInterval = function() {
    return this.__interval;
}

PauseSquare.setHtmls = function(htmls) {
    this.__htmls = htmls;
}

PauseSquare.getHtmls = function() {
    return this.__htmls;
}


PauseSquare.growup = function(pauseSquare) {
    if ((pauseSquare.getWidth() >= pauseSquare.getFinalWidth())
        && (pauseSquare.getHeight() >= pauseSquare.getFinalHeight())) {
        clearInterval(this.getInterval());
        this.getSquareDom().innerHTML = this.getHtmls();
        this.__growupState = "grown";
    }
    else {
        var width = pauseSquare.getWidth();
        if (width < pauseSquare.getFinalWidth()) {
            width += 5;
            var left = parseInt((screenWidth - width) / 2);
            pauseSquare.setLeft(left);
            pauseSquare.setWidth(width);
        }

        var height = pauseSquare.getHeight();
        if (height < pauseSquare.getFinalHeight()) {
            height += 5;
            var top = parseInt((screenHeight - height) / 2);
            pauseSquare.setTop(top);
            pauseSquare.setHeight(height);
        }
    }
}

PauseSquare.ungrowup = function(pauseSquare) {
    if ((pauseSquare.getWidth() <= 0) && (pauseSquare.getHeight() <= 0)) {
        clearInterval(this.getInterval());
        this.hide();
    }
    else {
        var width = pauseSquare.getWidth();
        if (width >0) {
            width -= 5;
            var left = parseInt((screenWidth - width) / 2);
            pauseSquare.setLeft(left);
            pauseSquare.setWidth(width);
        }

        var height = pauseSquare.getHeight();
        if (height >0) {
            height -= 5;
            var top = parseInt((screenHeight - height) / 2);
            pauseSquare.setTop(top);
            pauseSquare.setHeight(height);
        }
    }
}


//========以下为实现基类的抽象方法=========
PauseSquare.nextTime = function() {
    return true;
}

PauseSquare.init = function() {
    this.__machine.pause();
    this.setFinalWidth(this.getWidth());
    this.setFinalHeight(this.getHeight());
    this.setWidth(0);
    this.setHeight(0);
    this.setTop(0);
    this.setLeft(0);
    this.setClass(CLASSNAME_pauseSquare);
    this.show();
    this.setHtmls(this.getSquareDom().innerHTML);
    this.getSquareDom().innerHTML = "";
    //设置长大循环
    var me = this;
    var interval = setInterval(function() { me.growup(me) }, 10);
    this.setInterval(interval);
}

PauseSquare.uninit = function() {
    this.getSquareDom().innerHTML = "";
    //设置缩小循环
    var me = this;
    var interval = setInterval(function() { me.ungrowup(me) }, 10);
    this.setInterval(interval);
}

PauseSquare.execute = function() {
    if (this.__growupState == "grown") {
        this.__machine.start();
        this.isExecuted = true;
    }
}