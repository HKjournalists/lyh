﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== FloatMessageSquare类，继承至Square=======

var FloatMessageSquare = clone(Square);

FloatMessageSquare.__name = "floatMessageSquare";
FloatMessageSquare.__speed = 1;
FloatMessageSquare.__startTop = 400;
FloatMessageSquare.__endTop = 50;
FloatMessageSquare.__message = null;
FloatMessageSquare.__className = FloatMessageSquare.__name;

FloatMessageSquare.setSpeed = function(speed) {
    this.__speed = speed;
}
FloatMessageSquare.getSpeed = function() {
    return this.__speed;
}
FloatMessageSquare.setStartTop = function(top) {
    this.__startTop= top;
}
FloatMessageSquare.getStartTop = function() {
    return this.__startTop;
}
FloatMessageSquare.setEndTop = function(top) {
    this.__endTop = top;
}
FloatMessageSquare.getEndTop = function() {
    return this.__endTop;
}
FloatMessageSquare.setMessage = function(message) {
    this__message = message;
    var text = document.createTextNode(message);
    this.appendDom(text);
}
FloatMessageSquare.getMessage = function() {
    return this.__message;
}

//========以下为实现基类的抽象方法=========
FloatMessageSquare.nextTime = function() {
    this.moveToTop(this.getSpeed());
    if (this.getTop() <= this.getEndTop()) {
        return true;
    }
    else {
        return false;
    }
}

FloatMessageSquare.init = function() {
    this.setTop(this.__startTop);
    this.setLeft(0);
    this.setWidth(screenWidth-5);
    this.show();
}

FloatMessageSquare.uninit = function() {
    this.hide();
}

FloatMessageSquare.execute = function() {
    
}