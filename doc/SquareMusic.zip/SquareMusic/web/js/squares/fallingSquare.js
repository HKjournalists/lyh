﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== FallingSquare类，继承至Square=======

var FallingSquare = clone(Square);

FallingSquare.__name = "fallingSquare";
FallingSquare.__speed = 0;

FallingSquare.setSpeed = function(speed) {
    this.__speed = speed;
}
FallingSquare.getSpeed = function() {
    return this.__speed;
}

//========以下为实现基类的抽象方法=========

FallingSquare.nextTime = function() {
    this.moveToBottom(this.getSpeed());
    if (this.getTop() + this.getHeight() >= screenHeight) {
        return true;
    }
    else {
        return false;
    }
}

FallingSquare.init = function() {
    this.show();
}

FallingSquare.uninit = function() {
    this.hide();
}

FallingSquare.execute = function() {
    this.setSpeed(0);
    if (this.getClass().indexOf("Executed") < 0) {
        this.setClass(this.getClass() + "Executed");
    }
    this.isExecuted = true;
}