﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== DelaySquare类，继承至Square=======

var DelaySquare = clone(Square);
DelaySquare.__name = "delay";
DelaySquare.__time = 0;

DelaySquare.setTime = function(time) {
    this.__time = time;
}
DelaySquare.getTime = function() {
    return this.__time;
}

//========以下为实现基类的抽象方法=========

DelaySquare.nextTime = function() {
    return true;
}

DelaySquare.init = function() {
    this.__machine.addDelay(this.__time);
}

DelaySquare.uninit = function() {

}

DelaySquare.execute = function() {

}