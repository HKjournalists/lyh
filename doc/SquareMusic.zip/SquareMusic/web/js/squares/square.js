﻿///<reference path="styleUtil.js"/>

var Square = {
    isExecuted: false,
    __id: "No Id",
    __style: "",
    __className: "",
    __width: "",
    __height: "",
    __top: "",
    __left: "",
    __value: 0,
    __screen: null,
    __machine: null,
    __squareDom: null,


    //========必须被重新实现的变量=========
    __name: "Square",

    //========必须被重新实现的函数=========
    execute: function() {
        alert("出错了：square.js中的execute()函数没有被覆盖！调用者：" + this.getName());
    },
    //方块下一个时刻，返回false表示方块要消失
    nextTime: function() {
        alert("出错了：square.js中的nextTime()函数没有被覆盖！调用者：" + this.getName());
        return false;
    },
    init: function() {
        alert("出错了：square.js中的init()函数没有被覆盖！调用者：" + this.getName());
    },
    uninit: function() {
        alert("出错了：square.js中的uninit()函数没有被覆盖！调用者：" + this.getName());
    },
    //=========不应该被重新实现的函数=========
    setId: function(id) {
        this.__id = id;
        this.__squareDom.id = id;
    },
    getId: function() {
        return this.__id;
    },
    setValue: function(value) {
        this.__value = value;
    },
    getValue: function() {
        return this.__value;
    },
    setStyle: function(style) {
        this.__style = style;
        StyleUtil.setStyle(this.__squareDom, style);
    },
    getStyle: function() {
        return this.__style;
    },
    setClass: function(className) {
        this.__className = className;
        StyleUtil.setClass(this.__squareDom, className);
    },
    getClass: function() {
        return this.__className;
    },
    setTop: function(top) {
        if (top.toString().indexOf("%") >= 0) {
            this.__top = parseInt(parseFloat(top) * screenHeight / 100);
        }
        else {
            this.__top = parseInt(top);
        }

        StyleUtil.setAttribute(this.__squareDom, "top", this.__top);
    },
    getTop: function() {
        return this.__top;
    },
    setLeft: function(left) {
        if (left.toString().indexOf("%") >= 0) {
            this.__left = parseInt(parseFloat(left) * screenWidth / 100);
        }
        else {
            this.__left = parseInt(left);
        }

        StyleUtil.setAttribute(this.__squareDom, "left", this.__left);
    },
    getLeft: function() {
        return this.__left;
    },
    setWidth: function(width) {
    if (width.toString().indexOf("%") >= 0) {
            this.__width = parseInt(parseFloat(width) * screenWidth / 100);
        }
        else {
            this.__width = parseInt(width);
        }
        StyleUtil.setAttribute(this.__squareDom, "width", this.__width);
    },
    getWidth: function() {
        return this.__width;
    },
    setHeight: function(height) {
    if (height.toString().indexOf("%") >= 0) {
            this.__height = parseInt(parseFloat(height) * screenHeight / 100);
        }
        else {
            this.__height = parseInt(height);
        }

        StyleUtil.setAttribute(this.__squareDom, "height", this.__height);
    },
    getHeight: function() {
        return this.__height;
    },
    getRight: function() {
        return this.__left + this.__width;
    },
    getBottom: function() {
        return this.__top + this.__height;
    },
    setPosition: function(top, left) {
        this.setTop(top);
        this.setLeft(left);

    },
    setSize: function(width, height) {
        this.setWidth(width);
        this.setHeight(height);
    },
    setScreen: function(screen) {
        this.__screen = screen;
    },
    moveToLeft: function(offset) {
        if (offset == 0) return;
        var newLeft = Math.max(this.__left - offset, 0);
        this.setLeft(newLeft);
    },
    moveToRight: function(offset) {
        if (offset == 0) return;
        var newLeft = Math.min(this.__left + offset, screenWidth - this.__width);
        this.setLeft(newLeft);
    },
    moveToTop: function(offset) {
        if (offset == 0) return;
        var newTop = Math.max(this.__top - offset, 0);
        this.setTop(newTop);
    },
    moveToBottom: function(offset) {
        if (offset == 0) return;
        var newTop = Math.min(this.__top + offset, screenHeight - this.__height);
        this.setTop(newTop);
    },
    show: function() {
        this.__screen.addSquare(this.__squareDom);
    },
    hide: function() {
        this.__screen.removeSquare(this.__squareDom);
    },
    setSquareDom: function(squareDom) {
        this.__squareDom = squareDom;
    },
    getSquareDom: function() {
        return this.__squareDom;
    },
    setMachine: function(machine) {
        this.__machine = machine;
    },
    //不应该有setName()函数
    getName: function() {
        return this.__name;
    },
    isInclude: function(square) {
        if ((this.getLeft() <= square.getLeft())
        && (this.getTop() <= square.getTop())
        && (this.getRight() >= square.getRight())
        && (this.getBottom() >= square.getBottom())) {
            return true;
        }
        else {
            return false;
        }
    },
    appendDom: function(dom) {
        this.__squareDom.appendChild(dom);
    },
    getArea: function() {
        var width = this.__width / screenWidth * 100;
        var height = this.__height / screenHeight * 100;
        return parseInt(width * height);
    },
    isOverlap: function(square) {
        var l = Math.max(this.getLeft(), square.getLeft());
        var r = Math.min(this.getRight(), square.getRight());
        if (l >= r)
            return false;
        var t = Math.max(this.getTop(), square.getTop());
        var b = Math.min(this.getBottom(), square.getBottom());
        if (t >= b)
            return false;

        return true;
    }
};