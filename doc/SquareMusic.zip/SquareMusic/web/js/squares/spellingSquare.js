﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== SpellingSquare类，继承至Square=======

var SpellingSquare = clone(Square);

SpellingSquare.__name = "spellingSquare";
SpellingSquare.__speed = 0;

SpellingSquare.setSpeed = function(speed) {
    this.__speed = speed;
}
SpellingSquare.getSpeed = function() {
    return this.__speed;
}

//========以下为实现基类的抽象方法=========

SpellingSquare.nextTime = function() {
    this.moveToBottom(this.getSpeed());
    if (this.getTop() + this.getHeight() >= screenHeight) {
        return true;
    }
    else {
        return false;
    }
}

SpellingSquare.init = function() {
    this.show();
}

SpellingSquare.uninit = function() {
    this.hide();
}

SpellingSquare.execute = function() {
    this.setSpeed(0);
    if (this.getClass().indexOf("Executed") < 0) {
        this.setClass(this.getClass() + "Executed");
    }
    this.isExecuted = true;
}