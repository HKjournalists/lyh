﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== MouseSquare类，继承至Square,仅表示鼠标画出来的方块=======

var MouseSquare = clone(Square);

MouseSquare.__name = "mouseSquare";

//========以下为实现基类的抽象方法=========
