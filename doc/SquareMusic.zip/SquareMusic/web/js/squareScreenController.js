﻿var SquareScreenController = function() {
    this.__squareScreen = null;
    this.__machine = null;

    this.__mouseSquare = Object;

    this.__stateArray = {};
    this.__stateArray[MouseDownCrtlState.name] = new MouseDownCrtlState(this);
    this.__stateArray[MouseUpCtrlState.name] = new MouseUpCtrlState(this);
    this.__state = this.__stateArray[MouseUpCtrlState.name];
}


SquareScreenController.prototype.clearMouseSquare = function() {
    this.__squareScreen.clearMouseSquare();
}

SquareScreenController.prototype.drawMouseSquare = function(endX, endY) {
    var mouseSquare = this.__getMouseSquare(endX, endY);
    this.__squareScreen.drawMouseSquare(mouseSquare);
}

SquareScreenController.prototype.drawSquare = function(endX, endY) {
    var mouseSquare = this.__getMouseSquare(endX, endY);
    this.__machine.drawSquare(mouseSquare);
}

SquareScreenController.prototype.__getMouseSquare = function(endX, endY) {
    this.__mouseSquare.endX = endX;
    this.__mouseSquare.endY = endY;
    return SquareFactory.createMouseSquare(this.__mouseSquare.startX, this.__mouseSquare.endX, this.__mouseSquare.startY, this.__mouseSquare.endY);
}

SquareScreenController.prototype.setMouseSquare = function(startX, startY) {
    this.__mouseSquare.startX = startX;
    this.__mouseSquare.startY = startY;
}

SquareScreenController.prototype.setSquareScreen = function(squareScreen) {
    this.__squareScreen = squareScreen;
}

SquareScreenController.prototype.setSquaresMachine = function(machine) {
    this.__machine = machine;
}

SquareScreenController.prototype.setState = function(stateName) {
    this.__state = this.__stateArray[stateName];
}

SquareScreenController.prototype.machineSpaceDown = function() {
    this.__machine.spaceDown();
}

//==========鼠标、键盘事件========
SquareScreenController.prototype.mouseDown = function(oEvent) {
    this.__state.mouseDown(oEvent);
}

SquareScreenController.prototype.mouseMove = function(oEvent) {
    this.__state.mouseMove(oEvent);
}

SquareScreenController.prototype.mouseUp = function(oEvent) {
    this.__state.mouseUp(oEvent);
}

SquareScreenController.prototype.spaceDown = function() {
    this.__state.spaceDown();
}