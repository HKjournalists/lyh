﻿///<reference path="eventUtil.js"/>

function events_assignEvents() {
    //事件加载函数
    events_assignSquareScreen();
}

function events_assignSquareScreen() {
    var events_squareScreenDiv = document.getElementById(HTMLID_squareScreenDiv);
    events_squareScreenDiv.onmousedown = events_mouseDown;
    events_squareScreenDiv.onmousemove = events_mouseMove;
    events_squareScreenDiv.onmouseup = events_mouseUp;

    document.body.onkeydown = events_keyDown;
}

function events_mouseDown(event) {
    var oEvent = EventUtil.getEvent();
    squareScreenController.mouseDown(oEvent);
    oEvent.preventDefault();
}

function events_mouseMove(event) {
    var oEvent = EventUtil.getEvent();
    squareScreenController.mouseMove(oEvent);
    oEvent.preventDefault();
}

function events_mouseUp(event) {
    var oEvent = EventUtil.getEvent();
    squareScreenController.mouseUp(oEvent);
    oEvent.preventDefault();
}

function events_keyDown(event){
    var oEvent = EventUtil.getEvent();
    if (oEvent.keyCode == 32) {
        squareScreenController.spaceDown();
    }
    oEvent.preventDefault();
}