﻿var languages = new Array();

languages["chinese"] = {
    Gold: "金",
    lastGold: "刚才一抓:",
    storageGold: "碗里有:",
    winGole: "箩箩有:",
    originalGold: "本有:",
    overlapGold: "重叠丢失:",
    remainGold: "剩余:",
    interestGold: "利息:",
    loseStorageGold: "打破了碗，损失:"
}

//这里需要翻译 todo
languages["english"] = {
    Gold: "金",
    lastGold: "刚才一抓:",
    storageGold: "碗里有:",
    winGole: "箩箩有:",
    originalGold: "本有:",
    overlapGold: "重叠丢失:",
    remainGold: "剩余:",
    interestGold: "利息:",
    loseStorageGold: "打破了碗，损失:"
}