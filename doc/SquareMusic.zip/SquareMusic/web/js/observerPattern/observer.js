﻿var Observer = function(subject) {
    this.__subject = subject;
    this.__subject.registerObserver(this);

}

Observer.prototype.update = function() {
    alert("出错了：observer.js 中的update()函数没有被覆盖！");
}


