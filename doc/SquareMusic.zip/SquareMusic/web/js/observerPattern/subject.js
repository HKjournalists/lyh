﻿var Subject = function() {
    this.__observers = new Array();
}

Subject.prototype.registerObserver = function(observer) {
    this.__observers.push(observer);
}

Subject.prototype.notifyObservers = function() {
    var length = this.__observers.length;
    for (var i = 0; i < length; i++) {
        this.__observers[i].update();
    }
}


