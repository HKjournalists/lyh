﻿//game config
var gameSpeed = 10;
var language = "chinese";

//class name config
var CLASSNAME_squareScreen = "squareScreen";
var CLASSNAME_mouseSquare = "mouseSquare";
var CLASSNAME_floatMessageSquare = "floatMessageSquare";
var CLASSNAME_pauseSquare = "pauseSquare";
var CLASSNAME_stageChoiceSquare = "stageChoice";

//css value config
var cssValue_mouseSquareBorderWidth = 1;
var cssValue_squareBorderWidth = 2;

//html id config
var HTMLID_squareScreenDiv = "squareScreen";
var HTMLID_mouseSquare = "mouseSquare32";
var HTMLID_body = "body";

//fallingSquare's value
var FALLINGSQUARE_right = 1;
