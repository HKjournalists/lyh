﻿var SplitSquare = {
    split: function(s1, s2) {
        var retList = new Array();
        var length;
        if ((s2.getRight() <= s1.getRight()) && (s2.getRight() >= s1.getLeft())) {
            if ((s2.getLeft() <= s1.getRight()) && (s2.getLeft() >= s1.getLeft())) {
                if ((s2.getTop() >= s1.getTop()) && (s2.getTop() <= s1.getBottom())) {
                    if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {
                    }
                    else {
                        length = 1;
                        var dr = new Array(length);
                        retList = dr;
                        var l = new Array(length);
                        var r = new Array(length);
                        var t = new Array(length);
                        var b = new Array(length);

                        l[0] = s2.getLeft(); r[0] = s2.getRight(); t[0] = s1.getBottom(); b[0] = s2.getBottom();

                        for (var i = 0; i < length; i++)
                            dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                    }
                }
                else if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                    length = 1;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s2.getRight(); t[0] = s2.getTop(); b[0] = s1.getTop();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
                else if ((s2.getTop() <= s1.getTop()) && (s2.getBottom() >= s1.getBottom())) {

                    length = 2;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s2.getRight(); t[0] = s2.getTop(); b[0] = s1.getTop();
                    l[1] = s2.getLeft(); r[1] = s2.getRight(); t[1] = s1.getBottom(); b[1] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
            }
            else {


                if ((s2.getTop() >= s1.getTop()) && (s2.getTop() <= s1.getBottom())) {

                    if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                        length = 1;
                        var dr = new Array(length);
                        retList = dr;
                        var l = new Array(length);
                        var r = new Array(length);
                        var t = new Array(length);
                        var b = new Array(length);

                        l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();

                        for (var i = 0; i < length; i++)
                            dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                    }
                    else {

                        length = 2;
                        var dr = new Array(length);
                        retList = dr;
                        var l = new Array(length);
                        var r = new Array(length);
                        var t = new Array(length);
                        var b = new Array(length);

                        l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                        l[1] = s1.getLeft(); r[1] = s2.getRight(); t[1] = s1.getBottom(); b[1] = s2.getBottom();

                        for (var i = 0; i < length; i++)
                            dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                    }
                }
                else if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                    length = 2;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getLeft(); r[1] = s2.getRight(); t[1] = s2.getTop(); b[1] = s1.getTop();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
                else {

                    length = 3;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getLeft(); r[1] = s2.getRight(); t[1] = s2.getTop(); b[1] = s1.getTop();
                    l[2] = s1.getLeft(); r[2] = s2.getRight(); t[2] = s1.getBottom(); b[2] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
            }
        }
        else if ((s2.getLeft() <= s1.getRight()) && (s2.getLeft() >= s1.getLeft())) {


            if ((s2.getTop() >= s1.getTop()) && (s2.getTop() <= s1.getBottom())) {


                if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                    length = 1;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s1.getRight(); r[0] = s2.getRight(); t[0] = s2.getTop(); b[0] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
                else {

                    length = 2;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getRight(); t[0] = s1.getBottom(); b[0] = s2.getBottom();
                    l[1] = s1.getRight(); r[1] = s2.getRight(); t[1] = s2.getTop(); b[1] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
            }
            else if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                length = 2;
                var dr = new Array(length);
                retList = dr;
                var l = new Array(length);
                var r = new Array(length);
                var t = new Array(length);
                var b = new Array(length);

                l[0] = s2.getLeft(); r[0] = s1.getRight(); t[0] = s2.getTop(); b[0] = s1.getTop();
                l[1] = s1.getRight(); r[1] = s2.getRight(); t[1] = s2.getTop(); b[1] = s2.getBottom();

                for (var i = 0; i < length; i++)
                    dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
            }
            else {

                length = 3;
                var dr = new Array(length);
                retList = dr;
                var l = new Array(length);
                var r = new Array(length);
                var t = new Array(length);
                var b = new Array(length);

                l[0] = s2.getLeft(); r[0] = s1.getRight(); t[0] = s2.getTop(); b[0] = s1.getTop();
                l[1] = s2.getLeft(); r[1] = s1.getRight(); t[1] = s1.getBottom(); b[1] = s2.getBottom();
                l[2] = s1.getRight(); r[2] = s2.getRight(); t[2] = s2.getTop(); b[2] = s2.getBottom();

                for (var i = 0; i < length; i++)
                    dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
            }
        }
        else {

            if ((s2.getTop() >= s1.getTop()) && (s2.getTop() <= s1.getBottom())) {

                if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                    length = 2;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getRight(); r[1] = s2.getRight(); t[1] = s2.getTop(); b[1] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
                else {

                    length = 3;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getLeft(); r[1] = s1.getRight(); t[1] = s1.getBottom(); b[1] = s2.getBottom();
                    l[2] = s1.getRight(); r[2] = s2.getRight(); t[2] = s2.getTop(); b[2] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
            }
            else {

                if ((s2.getBottom() >= s1.getTop()) && (s2.getBottom() <= s1.getBottom())) {

                    length = 3;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getLeft(); r[1] = s1.getRight(); t[1] = s2.getTop(); b[1] = s1.getTop();
                    l[2] = s1.getRight(); r[2] = s2.getRight(); t[2] = s2.getTop(); b[2] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
                else {

                    length = 4;
                    var dr = new Array(length);
                    retList = dr;
                    var l = new Array(length);
                    var r = new Array(length);
                    var t = new Array(length);
                    var b = new Array(length);

                    l[0] = s2.getLeft(); r[0] = s1.getLeft(); t[0] = s2.getTop(); b[0] = s2.getBottom();
                    l[1] = s1.getLeft(); r[1] = s1.getRight(); t[1] = s2.getTop(); b[1] = s1.getTop();
                    l[2] = s1.getRight(); r[2] = s2.getRight(); t[2] = s2.getTop(); b[2] = s2.getBottom();
                    l[3] = s1.getLeft(); r[3] = s1.getRight(); t[3] = s1.getBottom(); b[3] = s2.getBottom();

                    for (var i = 0; i < length; i++)
                        dr[i] = SquareFactory.createSquare(l[i], t[i], r[i] - l[i], b[i] - t[i]);
                }
            }
        }
        return retList;
    }
}