﻿var StyleUtil = new Object;

StyleUtil.setStyle = function (item, styleString) {
    if (isIE) {
        item.style.cssText = styleString;
    } 
    else {
        item.setAttribute("style", styleString);
    }
}

StyleUtil.setAttribute = function (item, attributeName, attributeValue) {
    item.style[attributeName] = attributeValue;
}

StyleUtil.setClass= function (item, className){
    item.className = className;
}