﻿///<reference path="squaresMachineState.js"/>
///<reference path="xmldom.js"/>

var SquaresMachine = function() {
    SquaresMachine.superClass.constructor.call(this);
    //初始化状态
    this.__stateArray = new Array();
    this.__stateArray[FallingSquaresMachineState.name] = new FallingSquaresMachineState(this);
    this.__stateArray[SpellingSquaresMachineState.name] = new SpellingSquaresMachineState(this);
    //初始化属性
    this.__pause = true;
    this.__delay = 0;
    //设置循环
    var me = this;
    setInterval(function() { me.nextTime(me) }, gameSpeed);
}

extend(SquaresMachine, Subject);

SquaresMachine.prototype.nextTime = function(machine) {
    if (!machine.__pause) {
        if (machine.__delay > 0) {
            machine.__delay--;
        }
        machine.__state.nextTime();
    }
}

SquaresMachine.prototype.addDelay = function(delay) {
    this.__delay += delay;
}

SquaresMachine.prototype.getDelay = function() {
    return this.__delay;
}

SquaresMachine.prototype.start = function() {
    this.__pause = false;
}

SquaresMachine.prototype.pause = function() {
    this.__pause = true;
}

SquaresMachine.prototype.getSquares = function() {
    return this.__state.getSquares();
}

SquaresMachine.prototype.getState = function(stateName) {
    return this.__stateArray[stateName];
}

SquaresMachine.prototype.setState = function(stateName) {
    this.__state = this.__stateArray[stateName];
}

SquaresMachine.prototype.__setStage = function(stage) {
    this.__state.setStage(stage);
}

SquaresMachine.prototype.loadStage = function(path) {

    var stageXml = new XmlDom();
    stageXml.async = false; //设置同步加载
    stageXml.load(path);
    var stage = stageXml.documentElement;

    var defaultStateName = stage.getAttribute("defaultState");
    this.setState(defaultStateName);
    this.__setStage(stage);

    //启动机器
    this.__pause = false;
}

SquaresMachine.prototype.drawSquare = function(mouseSquare) {
    this.__state.drawSquare(mouseSquare);
}

SquaresMachine.prototype.spaceDown = function() {
    this.__state.spaceDown();
}

SquaresMachine.prototype.click = function() {
    this.__state.click();
}
