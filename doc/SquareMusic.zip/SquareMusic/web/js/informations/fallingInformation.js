﻿///<reference path="Information.js"/>
///<reference path="SquareFactory.js"/>

//======== FallingInformation类，继承至Information=======

var FallingInformation = clone(Information);
FallingInformation.__name = "fallingInformation";
FallingInformation.__html = "<label id=FI_last /><label id=FI_storage /><label id=FI_win />";
FallingInformation.__lastDom = null;
FallingInformation.__storageDom = null;
FallingInformation.__winDom = null;

FallingInformation.setLast = function(last) {
    this.__lastDom.data = last+languages[language].Gold;
}

FallingInformation.setStorage = function(storage) {
this.__storageDom.data = storage;
}

FallingInformation.setWin = function(win) {
this.__winDom.data = win;
}

//========以下为实现基类的抽象方法=========

FallingInformation.init = function() {
var label = document.createTextNode(languages[language].lastGold);
    this.appendDom(label);
    var labelLast = document.createTextNode("0" + languages[language].Gold);
    this.appendDom(labelLast);

    this.appendDom(document.createElement("br"));
    label = document.createTextNode(languages[language].storageGold);
    this.appendDom(label);
    var labelStorage = document.createTextNode("0" + languages[language].Gold);
    this.appendDom(labelStorage);

    this.appendDom(document.createElement("br"));
    label = document.createTextNode(languages[language].winGole);
    this.appendDom(label);
    var labelWin = document.createTextNode("0"+languages[language].Gold);
    this.appendDom(labelWin);

    this.__lastDom = labelLast;
    this.__storageDom = labelStorage;
    this.__winDom = labelWin;

    this.setId(FallingInformation.getName());
    this.setClass(FallingInformation.getName());
    this.show();
}