﻿///<reference path="square.js"/>
///<reference path="squareFactory.js"/>

//======== Information类，继承至Square=======

var Information = clone(Square);
Information.__name = "information";
Information.__html = "<div></div>";

Information.getHtml = function() {
    return this.__html;
}

//========以下为实现基类的抽象方法=========

Information.nextTime = function() {
    return false;
}

Information.init = function() {
    alert("出错了！Information.js 中的init()函数没有被覆盖。调用者:"+this.getName());
}

Information.execute = function() {
    
}