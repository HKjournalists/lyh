﻿var MouseUpCtrlState = function(controller) {
    MouseUpCtrlState.superClass.constructor.call(this, controller);
}

extend(MouseUpCtrlState, ControllerState);

MouseUpCtrlState.name = "mouseUpControllerState";

MouseUpCtrlState.prototype.mouseDown = function(oEvent) {
    this.__controller.clearMouseSquare();
    this.__controller.setMouseSquare(oEvent.clientX,oEvent.clientY);
    this.__controller.setState(MouseDownCrtlState.name);
}

MouseUpCtrlState.prototype.spaceDown = function() {
    this.__controller.machineSpaceDown();
}