﻿///<reference path="squareFactory.js"/>

var MouseDownCrtlState = function(controller) {
    MouseDownCrtlState.superClass.constructor.call(this, controller);
}

extend(MouseDownCrtlState, ControllerState);
MouseDownCrtlState.name = "mouseDownControllerState";

MouseDownCrtlState.prototype.mouseMove = function(oEvent) {
    this.__controller.clearMouseSquare();
    this.__controller.drawMouseSquare(oEvent.clientX, oEvent.clientY);
}

MouseDownCrtlState.prototype.mouseUp = function(oEvent) {
    this.__controller.setState(MouseUpCtrlState.name);
    this.__controller.clearMouseSquare();
    this.__controller.drawSquare(oEvent.clientX, oEvent.clientY);
}