﻿var ControllerState = function(controller) {
    this.__controller = controller;
}

ControllerState.name = "controllerSatae";

//==========子类必须覆盖的方法===========

ControllerState.prototype.mouseDown = function(oEvent) {
}

ControllerState.prototype.mouseMove = function(oEvent) {
}

ControllerState.prototype.mouseUp = function(oEvent) {
}

ControllerState.prototype.spaceDown = function() {
}
