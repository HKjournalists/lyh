﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uml
{
    public class SquareScreen
    {
        public SquareScreenController __controller
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
