﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uml
{
    public class SquareMachine
    {
        public SquaresMachineState __state
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
