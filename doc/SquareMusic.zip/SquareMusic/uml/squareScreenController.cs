﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uml
{
    public class SquareScreenController
    {
        public SquareMachine __squaresMachine
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public SquareScreen __squareScreen
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public ControllerState __state
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
