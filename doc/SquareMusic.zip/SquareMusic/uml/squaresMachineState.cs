﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uml
{
    public class SquaresMachineState
    {
        public SquareMachine __machine
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
