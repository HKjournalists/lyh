﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uml
{
    public class Square
    {
        public SquareScreen __screen
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public SquareMachine __machine
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
